## Exception Handling
## Error in Python can be of two types Syntax Error and Exceptions.
## Errors are the problems in the program due to which the program will stop execution.
## on the other hand, exceptions are raised when some internal events occur which
## changes the normal flow of the program

## try except block
## try except else block
## try except else finally block
## raise Exception

## difference between syntax error and exceptions:
#syntax error - caused by the wrong syntax in the code, it leads to the termination of the program
# amount = 10000
# if amount > 10000
# print("it's higher")

#Exceptions: are raised when the program is syntactically correct, but the code resulted in an error.
# try:
#     marks = 10000
#     a  = marks/0
#     print(a)
# except:
#     print("The code resulted in an exception")

try:
    a = [1,2,3]
    print(a[3])
except IndexError as e:
    print("Index Error:",e)
except ValueError as e:
    print("Value Error:",e)
except Exception as e:
    print("General Base Exception:",e)

try:
    a = [1,2,3]
    print(a.remove(8))
except IndexError as e:
    print("Index Error:",e)
except ValueError as e:
    print("Value Error:",e)
except Exception as e:
    print("General Base Exception:",e)


try:
    a = [1,2,3]
    print(b[3])
except IndexError as e:
    print("Index Error:",e)
except ValueError as e:
    print("Value Error:",e)
except Exception as e:
    print("General Base Exception:",e)

